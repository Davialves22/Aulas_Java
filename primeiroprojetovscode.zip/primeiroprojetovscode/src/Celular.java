public class Celular {
    // caracteristicas > atributos;
    String nome;
    String sistemaOperacional;
    int espacoArmazenamento;
    float tamanhoTela;
}
